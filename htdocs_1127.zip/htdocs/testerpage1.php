<?php

  echo "whatsup";
  echo "this is the first line of text";
  // variable
  $sometext = "harry potter";
  $somenumber = 32;
  echo $sometext.$somenumber;
  //basic math
  $anything = 34-6;
  $double = $anything * 2;
  echo $anything+$double;

?>
