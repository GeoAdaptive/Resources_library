<?php
// you MUST NOT keeo this function in your server phpinfo();
// phpinfo() will enable people to view your php installation and your website information

?>
