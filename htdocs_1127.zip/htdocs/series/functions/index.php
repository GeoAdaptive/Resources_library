<?php
function myName() {
  echo '<strong>Brian</strong><br>';
}
echo 'My name is <br>';
myName();

function addition($num1,$num2) {
  echo '<br>'.($num1 + $num2).'<br>';
}

// addition(1,3);
function displayDate($day, $date, $year) {
  echo $day.' '.$date.' '.$year;
}

displayDate('Monday', 3, 2017);

function add($num1, $num2){
  $sum = $num1 + $num2;
  return $sum;
}

echo '<br>'.(add(15,7) + 100).'<br>';

//global variables
$user_ip = $_SERVER['REMOTE_ADDR'];
//why I always get a weird IP address? looks like :::1 ?
function echo_ip () {
  // to match this variable within the function with the global variable outside.
  global $user_ip;
  $string = 'Your IP address is:'.$user_ip;
  echo $string;
}

echo_ip();
?>
