<?php

// switch statement
$number = 0;
$day = 'Saturday';

//example 1 switch number
switch ($number) {
  case 1:
    echo 'One';
  break;

  case 2:
    echo 'Two';
  break;

  case 3:
    echo 'Three';
  break;

  default:
    echo 'Number not found.';
  break;
}

//example 2 day of week
switch ($day) {
  case 'Saturday':
  case 'Sunday':
    echo 'It\'s a weekend.';
  break;
  
  default:
    echo 'Not a weekend.';
  break;
}

?>
