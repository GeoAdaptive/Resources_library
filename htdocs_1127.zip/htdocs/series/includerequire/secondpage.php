<?php

include 'header.inc.php';

echo $var1;
echo $var2;

?>
