<h1>My PHP Page</h1>
<?php
$var1 = 'String';
$var2 = 10;
?>
