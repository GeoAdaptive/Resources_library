<?php

//this is a very useful function to keep embedding the same template over multiple pages.
include 'header.inc.php';

// require will check if the page exists, and will kills off the following page if not.
//require_once can make sure it only checks once and fasten the speed.
require_once 'header.inc.php';

// if (defined('header.inc.php')) {
//   require 'header.inc.php';
// }

// $var = 'String';
// echo $var;


?>
