<?php
$name = "Alex";
$age = "21";
if (strtolower($name) === "alex"){
  if ($age >= 21){
    echo "you are over 21!";
    if (1 === 1){
      echo "1 is equal to 1!";
    }
  } else {
    echo "not over 21!";
  }
} else {
  echo "you are not Alex!";
}

?>
