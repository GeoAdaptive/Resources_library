<?php
  //you can create a whole html within the echo constructor
  echo "<strong>this</strong> echo constructor output content to your browser.";
  print ("<strong>Hello!</strong>");
?>
