<?php

/*
comments for multiple lines
Date: 11/25/2017
*/

//users echo language construct to output the text
echo "Hello World"; //comments can also go in here

?>
