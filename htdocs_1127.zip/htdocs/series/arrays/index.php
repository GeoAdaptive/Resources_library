<?php
//array
$food = array ('Pasta'=>300,'Pizza'=>1000,'Salad'=>150,'Banana'=>100);

print_r ($food);
//associate array with updated data but with fixed keys
print_r ($food['Pasta']);
echo $food['Salad'];
// $food[4] = 'Fruit';
// print_r($food);

//multi-dimensional arrays
/*
Healthy
Salad
Vegetables
Fruits

Unhealthy
Pizza
Ice cream
*/

$foodnew = array ('Healthy'=>
                            array('Salad', 'Vegetables', 'Fruits'),
                  'Unhealthy'=>
                            array('Pizza','Ice cream'));

echo '<br>'.$foodnew['Healthy'][0];


//for each loop
foreach($foodnew as $element => $inner_array) {
  echo '<br><strong>'.$element.'</strong><br>';
  foreach ($inner_array as $item) {
      echo $item.'<br>';
  }

}


?>
