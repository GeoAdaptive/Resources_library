<?php
//define the variables first
$text = 'Hello';
$number = 100;
$bool = true;

//choose which variables to output
echo $number;

?>
