<?php

echo 'Hello';

//die () or exit () can be useful in connecting with database.
mysqli_connect('localhost','brian','') or die ('Could not connect to the database.');

echo 'Connected!';

// die ('<br>ERROR. Page has ended.');
//or exit ();

echo 'World';


?>
