<?php

$string = 'This is a string.';
// preg_match();

//search for expression in the given string
if (preg_match('/is/',$string)) {
  echo 'Match found!<br>';
} else {
  echo 'No match found!<br>';
}

function has_space($string) {
  if (preg_match('/ /',$string)){
    return true;
  } else {
    return false;
  }
}
if (has_space('Thisdoesnothavespace')) {
  echo 'Has a space.';
} else {
  echo 'Has no space.';
}

?>
