<?php

$time = time();
$time_now = date('M d Y @ H:i:s', $time);
$time_modified = date('M d Y @ H:i:s', strtotime('-1 week'));
//
// echo 'The current time is '.$time;
echo 'The time now is '.$time_now.'<br>The time modified is '.$time_modified;
?>
