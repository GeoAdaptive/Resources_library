<!-- <input type = "next"; name = "name"> -->
<?php
echo "<input type = \"next\"; name = \"name\" value = \"Brian\">";
?>
