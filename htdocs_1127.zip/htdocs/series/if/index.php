<?php

// $text = 'brian';
//
// if ($text == 'brian') {
//   echo 'TRUE.';
// } else {
//   echo 'FALSE.';
// }

$number = 14;

if ($number == 10) {
  echo 'equal to 10';
} else if ($number == 11) {
  echo 'equal to 11';
} else {
  echo 'Not equal';
}

?>
