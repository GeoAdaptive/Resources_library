<?php
$text = "Jack";
echo "Hello World";

?>

<input type = "text" value = "<?php echo $text; ?>">
