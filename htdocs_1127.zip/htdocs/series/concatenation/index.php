<?php
$day = 'Thursday';
$date = 31;
$year = 2017;

// the default way
echo 'The date is <strong>'.$day.'</strong> '.$date.' '.$year;
// the easier way
echo "The date is <strong>$day</strong> $date $year.";

?>
