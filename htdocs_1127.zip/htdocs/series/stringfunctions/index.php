<?php

$string = ' This is an example string.';
//conversion string to array
$string_word_count = str_word_count($string, 1, '.');
//print out the array converted
print_r ($string_word_count);

//string shuffle
//randomly generate some texts, generate random ID, etc.
$string_shuffled = str_shuffle($string);
$reverse = strrev($string);

//substr () needs the string, the start and the end positions of the cut version.
$half = substr($string_shuffled, 0, strlen($string)/2);

//string length
$string_length = strlen($string);

//trimming
$string_trimmed = trim($string);

//add slashes
$string1 = 'This is a <img src="image.jpg"> string.';
$string_slashes = htmlentities(addslashes( $string1 ));


echo $string_shuffled;
echo $reverse;
echo '<br>The length of the string is '.$string_length.'.<br>';
echo '<br>'.$half;
echo $string_trimmed;
echo $string_slashes;

//comparing two strings for similarity
$string_one = 'The first string to be tested.';
$string_two = 'The second string is this one.';

similar_text($string_one, $string_two, $result);
echo '<br>The similarity between is, <strong>'.$result.'</strong>';



?>
