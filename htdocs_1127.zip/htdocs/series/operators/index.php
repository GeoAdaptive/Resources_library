<?php

$number1 = 10;
$number2 = 9;
$number3 = 8;
$sum = 10 + 20;

$num1 = '1';
$num2 = 1;

// triple equals === compares both the value and the data types.
if ($num1 === $num2) {
  echo 'Equal.';
} else {
  echo 'Not equal.';
}

if ($number1 > $number2 && !($number2 > $number3)) {
  echo 'Descending.';
} else {
  echo 'Not descending.';
}

echo $sum;
$sum++;
echo $sum;
$sum++;
echo $sum;


// $result = $number1 + 2;

// arithmetic operators
/*
+ - * / %
++ --
*/



?>
