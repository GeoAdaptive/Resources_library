<?php

$counter = 1;

// if you don't know the number of loops
while ( $counter <= 10 ) {
  echo 'Hello <br> second line. <br><br>';
  $counter ++;
}

// the do loop will run the block at least onece.
do {
  echo 'This will always show. <br>';
  $counter ++;
} while ( $counter <= 25 );

// for loop
for ($count = 10; $count >= 1; $count--) {
  echo $count.'<br>';
}

?>
