Outside content.
<input type = "text" value = "jack">

<?php
// error_reporting(0);
// error_reporting('E_ALL');
echo $var = 'Alex';
// echo $var2;

?>
