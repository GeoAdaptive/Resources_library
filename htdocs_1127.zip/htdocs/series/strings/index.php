<?php

$string = 'Brian';
$string_length = strlen($string);

for ($x = 1; $x <= $string_length; $x++) {
  echo $x.'<br>';
}

//upper and lower case conversion
$string = 'I could DO this in two dayS!';
$string_lower = strtolower($string);
$string_upper = strtoupper($string);

echo $string_lower;
echo $string_upper;

//An example of how this could be used
if (isset($_GET['user_name']) && !empty($_GET['user_name'])) {
  $user_name = $_GET['user_name'];

  if (strtolower($user_name) == 'alex') {
    echo 'You are the best.'.$user_name;
  }

}
?>

<br>
<br>
<form action = "index.php" method = "GET">
  Name: <input type = "text" name = "user_name"><br><br>
  <input type = "submit" value = "Submit">
</form>

<?php
  $offset = 0;
  $find = 'the';
  $find_length = strlen($find);

  $string = 'America is the largest economy in the world in the 20th century.';
  //strpos(string to be searched, the search item, the search start position)
  echo strpos($string, $find, 0);

  while ($string_position = strpos($string, $find, $offset)) {
    echo '<br><strong>"'.$find.'"</strong> is found at '.$string_position.'<br>';
    $offset = $string_position + $find_length;
  }

?>

<?php
//replace partially
$string = 'This part don\'t search. This part search.';
$string_new = substr_replace($string, 'alex', 29, 4);

echo '<br>'.$string_new;

?>

<?php
//replace function
$list = array('communist','money','crackdown');

$string = 'This is a communist group in the money-making world full with regular crackdowns.';

$new_string = str_replace($list, '', $string);

echo '<br>'.$string;
echo '<br>'.$new_string;

?>
