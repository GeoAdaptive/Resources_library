<?php
// here goes the php code
echo "first page";
?>

<html>
The first php page
</html>
